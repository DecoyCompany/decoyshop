package com.decoyshop.decoyshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecoyshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecoyshopApplication.class, args);
	}

}

package com.decoyshop.decoyshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DecoyshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
